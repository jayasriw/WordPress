<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

if($job_id){
	$jobs_id = $job_id;
} else {
	$jobs_id = get_the_ID();
}
$custom_jobs_image_size = jobportal_get_option('single_jobs_image_size');
$jobs_select_company    = get_post_meta($jobs_id, JOBPORTAL_METABOX_PREFIX . 'jobs_select_company');
$company_id = isset($jobs_select_company[0]) ? $jobs_select_company[0] : '';
$width = '';
$height = '';
$image_src = '';
$classes = array();

if (preg_match('/\d+x\d+/', $custom_jobs_image_size)) {
    $attach_id = get_post_thumbnail_id($jobs_id);
    $image_sizes = explode('x', $custom_jobs_image_size);
    $width         = $image_sizes[0];
    $height         = $image_sizes[1];
    $image_src      = jobportal_image_resize_id($attach_id, $width, $height, true);
}

$single_jobs_style = jobportal_get_option('single_jobs_style');
// Support ?style=large-cover-img or ?layout=large-cover-img (or cover-img, no-image) for style
if (!empty($_GET['style'])) {
    $single_jobs_style = jobportal_clean(wp_unslash($_GET['style']));
} elseif (!empty($_GET['layout']) && in_array($_GET['layout'], array('cover-img', 'no-image', 'large-cover-img'))) {
    $single_jobs_style = jobportal_clean(wp_unslash($_GET['layout']));
}
if ($single_jobs_style == 'large-cover-img') {
    $classes[] = 'has-large-thumbnail';
}

// Type 2 - No Image: Don't display thumbnail
if ($single_jobs_style == 'no-image') {
    return;
}

if (has_post_thumbnail($jobs_id)) : ?>
    <div class="jobs-thumbnail-details <?php echo implode(" ", $classes); ?>">
        <?php if ($width !== '' & $height !== '') { ?>
            <img width="<?php echo esc_attr($width) ?>" height="<?php echo esc_attr($height) ?>" src="<?php echo esc_url($image_src) ?>" alt="<?php echo get_the_title($jobs_id); ?>" />
        <?php } else { ?>
            <?php echo the_post_thumbnail(); ?>
        <?php } ?>
    </div>
<?php endif; ?>
