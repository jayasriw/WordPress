<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
global $current_user;
$user_id = apply_filters('jobportal_modify_user_id', $current_user->ID);
$candidate_id = get_the_ID();
$author_id = get_post_field('post_author', $candidate_id);
$args = array(
    'posts_per_page' => -1,
    'post_type' => 'jobs',
    'post_status' => 'publish',
    'ignore_sticky_posts' => 1,
    'author' => $user_id,
    'meta_query' => array(
        array(
            'key' => JOBPORTAL_METABOX_PREFIX . 'enable_jobs_package_expires',
            'value' => 0,
            'compare' => '=='
        )
    ),
);
$the_query = new WP_Query($args);
$my_invite = get_user_meta($author_id, JOBPORTAL_METABOX_PREFIX . 'my_invite', true);
?>

<div class="form-popup jobportal-form-invite" id="form-invite-popup">
    <div class="bg-overlay"></div>
    <form class="invite-popup custom-scrollbar">
        <a href="#" class="btn-close"><i class="far fa-times"></i></a>
        <div class="popup-header">
            <h5><?php esc_html_e('Invite to apply job', 'jobportal-framework'); ?></h5>
            <p><?php esc_html_e('Select job to invite this user', 'jobportal-framework'); ?></p>
        </div>
        <?php
        $list_jobs = array();
        if ($the_query->have_posts()) { ?>
            <ul class="type filter-control custom-scrollbar">
                <?php while ($the_query->have_posts()) :
                    $the_query->the_post();
                    $css_class = '';
                    $key = false;
                    $jobs_id = get_the_ID();
                    $list_jobs[] = get_the_ID();
                    $jobs_title = get_the_title($jobs_id);
                    if (!empty($my_invite)) {
                        $key = array_search($jobs_id, $my_invite);
                    }
                    if ($key !== false) {
                        $css_class = 'checked';
                    }
                ?>
                    <li>
                        <input type="checkbox" id="jobportal_<?php echo esc_attr($jobs_id); ?>" class="custom-checkbox input-control" name="jobs_invite[]" <?php echo esc_attr($css_class); ?> value="<?php echo esc_attr($jobs_id); ?>">
                        <label for="jobportal_<?php echo esc_attr($jobs_id); ?>">
                            <?php esc_html_e($jobs_title); ?>
                            <?php if ($css_class === 'checked') : ?>
                                <span class="badge-invited"><?php esc_html_e('Invited', 'jobportal-framework'); ?></span>
                            <?php endif; ?>
                        </label>
                    </li>
                <?php endwhile; ?>
            </ul>
            <div class="button-wrapper">
                <a href="#" class="jobportal-button button-outline button-block jobportal-clear-invite"><?php esc_html_e('Clear', 'jobportal-framework'); ?></a>
                <a href="#" class="jobportal-button button-block" id="btn-saved-invite">
                    <?php esc_html_e('Invite', 'jobportal-framework'); ?>
                    <span class="btn-loading"><i class="fal fa-spinner fa-spin large"></i></span>
                </a>
            </div>
            <input type="hidden" name="candidate_id" value="<?php echo esc_attr($candidate_id) ?>" />
            <input type="hidden" name="author_id" value="<?php echo esc_attr($author_id) ?>" />
            <input type="hidden" name="list_jobs" value="<?php echo esc_attr(json_encode($list_jobs)) ?>" />
        <?php } else { ?>
            <div class="item-not-found"><?php esc_html_e('No item found', 'jobportal-framework'); ?></div>
        <?php } ?>
    </form>
</div>
