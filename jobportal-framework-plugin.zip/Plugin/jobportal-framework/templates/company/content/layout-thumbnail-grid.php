<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

global $wpdb;

$id = get_the_ID();
if (!empty($company_id)) {
    $id = $company_id;
}
$company_meta_data = get_post_custom($id);
$company_location = get_the_terms($company_id, 'company-location');
$company_categories =  get_the_terms($company_id, 'company-categories');
$company_size =  get_the_terms($company_id,  'company-size');
$company_logo   = get_post_meta($company_id, JOBPORTAL_METABOX_PREFIX . 'company_logo');
$company_item_class[] = 'jobportal-company-item';
if (!empty($layout)) {
    $company_item_class[] = $layout;
}
$company_item_class[] = 'company-' . $id;
$meta_query = jobportal_posts_company($id);

$custom_company_image_size = jobportal_get_option('archive_company_thumbnail_size');
$width = $height = '';
if (preg_match('/\d+x\d+/', $custom_company_image_size)) {
    $attach_id = get_post_thumbnail_id($company_id);
    $image_sizes = explode('x', $custom_company_image_size);
    $width         = $image_sizes[0];
    $height         = $image_sizes[1];
    $image_src      = jobportal_image_resize_id($attach_id, $width, $height, true);
}

?>
<div class="<?php echo join(' ', $company_item_class); ?>">
    <?php if (has_post_thumbnail()) : ?>
        <div class="company-thumbnail">
            <?php if ($width !== '' & $height !== '') { ?>
                <img width="<?php echo esc_attr($width) ?>" height="<?php echo esc_attr($height) ?>" src="<?php echo esc_url($image_src) ?>" alt="<?php echo get_the_title($company_id); ?>" />
            <?php } else { ?>
                <?php echo the_post_thumbnail(); ?>
            <?php } ?>
        </div>
    <?php endif; ?>
    <div class="company-top">
        <div class="company-logo">
            <a class="company-img" href="<?php echo get_the_permalink($company_id); ?>">
                <?php if (!empty($company_logo[0]['url'])) : ?>
                    <img class="logo-company" src="<?php echo $company_logo[0]['url'] ?>" alt="" />
                <?php else : ?>
                    <div class="logo-company"><i class="far fa-camera"></i></div>
                <?php endif; ?>
            </a>
        </div>
        <div class="company-content">
            <?php if (!empty(get_the_title($company_id))) : ?>
                <h2 class="company-title">
                    <a href="<?php echo get_the_permalink($company_id); ?>"><?php echo get_the_title($company_id); ?></a>
                </h2>
                <?php jobportal_company_green_tick($company_id); ?>
            <?php endif; ?>
            <div class="company-inner">
                <?php if (is_array($company_location)) { ?>
                    <div class="company-location">
                        <?php foreach ($company_location as $location) {
                            $location_link = get_term_link($location, 'company-size'); ?>
                            <a href="<?php echo esc_url($location_link); ?>" class="cate jobportal-link-bottom">
                                <i class="fas fa-map-marker-alt"></i><?php esc_html_e($location->name); ?>
                            </a>
                        <?php } ?>
                    </div>
                <?php } ?>
                <?php echo jobportal_get_total_rating('company', $company_id); ?>
            </div>
        </div>
    </div>
    <div class="company-bottom">
        <?php if (is_array($company_categories)) { ?>
            <div class="company-cate">
                <?php foreach ($company_categories as $categories) {
                    $cate_link = get_term_link($categories, 'company-categories'); ?>
                    <a href="<?php echo esc_url($cate_link); ?>" class="label label-categories">
                        <i class="far fa-folder"></i><?php esc_html_e($categories->name); ?>
                    </a>
                <?php } ?>
            </div>
        <?php } ?>
        <?php if ($meta_query->post_count > 0) : ?>
            <div class="company-available">
                <span><?php echo $meta_query->post_count; ?></span> <?php esc_html_e('jobs available', 'jobportal-framework') ?>
            </div>
        <?php endif; ?>
    </div>
    <a class="jobportal-link-item" href="<?php echo get_post_permalink($company_id) ?>"></a>
</div>
