<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

if (!is_user_logged_in()) {
    jobportal_get_template('global/access-denied.php', array('type' => 'not_login'));
    return;
}

wp_enqueue_script(JOBPORTAL_PLUGIN_PREFIX . 'follow-candidate');
wp_localize_script(
    JOBPORTAL_PLUGIN_PREFIX . 'follow-candidate',
    'jobportal_follow_candidate_vars',
    array(
        'ajax_url'    => JOBPORTAL_AJAX_URL,
        'not_candidate'   => esc_html__('No candidate found', 'jobportal-framework'),
    )
);

global $current_user;
$user_id = $current_user->ID;
$follow_candidate    = get_user_meta($user_id, JOBPORTAL_METABOX_PREFIX . 'follow_candidate', true);
$posts_per_page = 10;
$user_demo = get_the_author_meta(JOBPORTAL_METABOX_PREFIX . 'user_demo', $user_id);

if (empty($follow_candidate)) {
    $follow_candidate = array(0);
}
$args = array(
    'post_type'           => 'candidate',
    'post__in'            => $follow_candidate,
    'ignore_sticky_posts' => 1,
    'posts_per_page'      => $posts_per_page,
    'offset'              => (max(1, get_query_var('paged')) - 1) * $posts_per_page,
);
$data_candidate = new WP_Query($args);
?>

<div class="jobportal-follow-candidate">
    <div class="search-dashboard-wrapper">
        <div class="search-left">
            <div class="action-search">
                <input class="search-control" type="text" name="candidate_search" placeholder="<?php esc_attr_e('Find by name', 'jobportal-framework') ?>">
                <button class="btn-search">
                    <i class="far fa-search"></i>
                </button>
            </div>
        </div>
        <div class="search-right">
            <label class="text-sorting"><?php esc_html_e('Sort by', 'jobportal-framework') ?></label>
            <div class="select2-field">
				<select class="search-control action-sorting jobportal-select2" name="candidate_sort_by">
					<option value="newest"><?php esc_html_e('Newest', 'jobportal-framework') ?></option>
					<option value="oldest"><?php esc_html_e('Oldest', 'jobportal-framework') ?></option>
				</select>
			</div>
        </div>
    </div>
    <?php if ($data_candidate->have_posts()) { ?>
        <div class="table-dashboard-wapper">
            <table class="table-dashboard" id="follow-candidate">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Name', 'jobportal-framework') ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($data_candidate->have_posts()) : $data_candidate->the_post(); ?>
                        <?php
                        global $post;
                        $author_id = $post->post_author;
                        $id = get_the_ID();
                        $candidate_current_position   = get_post_meta($id, JOBPORTAL_METABOX_PREFIX . 'candidate_current_position', true);
                        $candidate_locations = get_the_terms($id, 'candidate_locations');
                        $candidate_email = get_post_meta($id, JOBPORTAL_METABOX_PREFIX . 'candidate_email', true);
                        $candidate_avatar = get_the_author_meta('author_avatar_image_url', $author_id);
                        $candidate_featured = get_post_meta($id, JOBPORTAL_METABOX_PREFIX . 'candidate_featured', true);
                        ?>
                        <tr>
                            <td class="info-user">
                                <?php if (!empty($candidate_avatar)) : ?>
                                    <img class="image-candidates" src="<?php echo esc_url($candidate_avatar) ?>" alt="" />
                                <?php else : ?>
                                    <div class="image-candidates"><i class="far fa-camera"></i></div>
                                <?php endif; ?>
                                <div class="info-details">
                                    <h3>
                                        <a href="<?php echo esc_url(get_the_permalink($id)); ?>"><?php esc_html_e(get_the_title($id)); ?></a>
                                        <?php if ($candidate_featured == 1) : ?>
                                            <span class="tooltip" data-title="<?php echo esc_attr__('Featured', 'jobportal-framework') ?>"><i class="fas fa-check"></i></span>
                                        <?php endif; ?>
                                    </h3>
                                    <div class="cate-info">
                                        <?php if (!empty($candidate_current_position)) { ?>
                                            <div class="candidate-current-position">
                                                <?php esc_html_e($candidate_current_position . ' / '); ?>
                                            </div>
                                        <?php } ?>
                                        <?php jobportal_get_salary_candidate($id, '-'); ?>
                                        <?php if (is_array($candidate_locations)) {
                                            foreach ($candidate_locations as $location) { ?>
                                                <?php esc_html_e(' / ' . $location->name); ?>
                                        <?php }
                                        } ?>
                                    </div>
                                </div>
                            </td>
                            <td class="action-setting">
                                <div class="list-action">
                                    <a href="<?php echo esc_url(get_the_permalink($id)); ?>" target="_blank" class="action icon-view tooltip" data-title="<?php echo esc_attr__('View', 'jobportal-framework') ?>"><i class="far fa-eye"></i></i></a>
                                    <a href="mailto: <?php esc_html_e($candidate_email); ?>" class="action icon-gmail tooltip" data-title="<?php echo esc_attr__('Send Email', 'jobportal-framework') ?>"><i class="far fa-envelope-open-text"></i></a>

                                    <?php if ($user_demo == 'yes') : ?>
                                        <a href="#" class="btn-add-to-message action tooltip" data-text="<?php echo esc_attr__('This is a "Demo" account so you not cant delete it', 'jobportal-framework'); ?>" data-title="<?php echo esc_attr__('Delete', 'jobportal-framework') ?>"><i class="far fa-trash-alt"></i></a>
                                        </a>
                                    <?php else : ?>
                                        <a href="#" class="action btn-delete tooltip" items-id="<?php echo esc_attr($id); ?>" data-title="<?php echo esc_attr__('Delete', 'jobportal-framework') ?>"><i class="far fa-trash-alt"></i></a>
                                    <?php endif; ?>

                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <div class="jobportal-loading-effect"><span class="jobportal-dual-ring"></span></div>
        </div>
    <?php } else { ?>
        <div class="item-not-found"><?php esc_html_e('No item found', 'jobportal-framework'); ?></div>
    <?php } ?>
    <?php $total_post = $data_candidate->found_posts;
    if ($total_post > $posts_per_page) { ?>
        <div class="pagination-dashboard">
            <?php $max_num_pages = $data_candidate->max_num_pages;
            jobportal_get_template('global/pagination.php', array('total_post' => $total_post, 'max_num_pages' => $max_num_pages, 'type' => 'dashboard', 'layout' => 'number'));
            wp_reset_postdata(); ?>
        </div>
    <?php } ?>
</div>
